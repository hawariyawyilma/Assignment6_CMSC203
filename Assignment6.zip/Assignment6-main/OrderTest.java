import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class OrderTest {

	Order a;
	@BeforeEach
	void setUp() throws Exception {
	a = new Order(10,Day.MONDAY,new Customer("Bob",25));
	}

	@AfterEach
	void tearDown() throws Exception {
	a = null;
	}

	@Test
	void testOrder() {
		assertNotNull(a);
	}

	@Test
	void testGenerateOrder() {
		int b = a.generateOrder();
		assertTrue(b > 10000 && b < 90000);
	}

	@Test
	void testGetOrderNo() {
		assertTrue(a.getOrderNo() > 10000 && a.getOrderNo() < 90000);
	}

	@Test
	void testGetOrderTime() {
		assertTrue(a.getOrderTime()==10);
	}

	@Test
	void testGetOrderDay() {
		assertTrue(a.getOrderDay()==Day.MONDAY);
	}

	@Test
	void testGetCustomer() {
		assertTrue(a.getCustomer().getAge()==25 && a.getCustomer().getName().equals("Bob"));
	}

	@Test
	void testGetDay() {
		assertTrue(a.getOrderDay()==Day.MONDAY);
	}

	@Test
	void testIsWeekend() {
		assertFalse(a.isWeekend());
	}

	@Test
	void testGetBeverage() {
		a.addNewBeverage("", Size.SMALL);
		assertNotNull(a.getBeverage(0));
	}

	@Test
	void testGetTotalItems() {
		a.addNewBeverage("", Size.SMALL);
		a.addNewBeverage("", Size.SMALL);
		assertEquals(a.getTotalItems(),2);
	}

	@Test
	void testAddNewBeverageStringSizeBooleanBoolean() {
		a.addNewBeverage("", Size.SMALL,false,false);
		assertNotNull(a.getBeverage(0));
	}

	@Test
	void testAddNewBeverageStringSize() {
		a.addNewBeverage("", Size.SMALL);
		assertNotNull(a.getBeverage(0));
	}

	@Test
	void testAddNewBeverageStringSizeIntBoolean() {
		a.addNewBeverage("", Size.SMALL,0,false);
		assertNotNull(a.getBeverage(0));
	}

	@Test
	void testCalcOrderTotal() {
		a.addNewBeverage("", Size.SMALL);
		a.addNewBeverage("", Size.SMALL);
		assertEquals(a.calcOrderTotal(),4);
	}

	@Test
	void testFindNumOfBeveType() {
		a.addNewBeverage("", Size.SMALL);
		a.addNewBeverage("", Size.SMALL);
		assertTrue(a.findNumOfBeveType(Type.ALCOHOL)==2);
	}

	@Test
	void testToString() {
		a.addNewBeverage("", Size.SMALL);
		a.addNewBeverage("", Size.SMALL,false,false);
		System.out.println(a.toString());
		assertTrue(a.toString().contains("10,MONDAY,Bob,25"));
		assertTrue(a.toString().contains("ALCOHOL,$2.0"));
		assertTrue(a.toString().contains("COFFEE,$2.0"));
	}

	@Test
	void testCompareTo() {
		Order b = new Order(10,Day.MONDAY,new Customer("Bob",25));
		if(b.getOrderNo()>a.getOrderNo())
			assertTrue(a.compareTo(b)==-1);
		else if (b.getOrderNo()<a.getOrderNo())
			assertTrue(a.compareTo(b)==1);
		else assertTrue(a.compareTo(b)==0);
	}

}
