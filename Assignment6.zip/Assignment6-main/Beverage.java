

public abstract class Beverage {
	private String bevName;
	private Type type;			// Stores drink information: name, type, and size
	private Size size;
	private final double BASE_PRICE = 2.00;	// Stores base cost for beverage
	private final double SIZE_PRICE = 1.00;	// Stores cost to increase size price by one
	
	public Beverage(String bevName, Type type, Size size) {
		this.bevName = bevName;
		this.type = type;
		this.size = size;
	}
	
	public double getBasePrice() {
		return BASE_PRICE;
	}
	
	public Type getType() {
		return type;
	}
	
	public String getBevName() {
		return bevName;
	}
	
	public Size getSize() {
		return size;
	}
	
	public double addSizePrice() {	// Calculates a drink's price from its size
		switch(size) {
		case SMALL: return BASE_PRICE;
		case MEDIUM: return BASE_PRICE + SIZE_PRICE;
		case LARGE: return BASE_PRICE + (SIZE_PRICE * 2);
		default: return 0;
		}
	}
	
	public String toString() {	// Represents the drink data in String format
		return bevName + "," + size;
	}
	
	public abstract double calcPrice();	// Represents abstract function for calculating drink's final price
	
	public boolean equals(Beverage anotherBev) {	// Checks if two drinks are the same
		return (bevName.equals(anotherBev.getBevName()) && size == anotherBev.getSize() && type == anotherBev.getType());
	}
}
