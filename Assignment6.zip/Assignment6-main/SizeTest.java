import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SizeTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		BevShop a = new BevShop();
		a.startNewOrder(10, Day.MONDAY, "", 25);
		a.processAlcoholOrder("", Size.SMALL);
		a.processAlcoholOrder("", Size.MEDIUM);
		a.processAlcoholOrder("", Size.LARGE);
	}

}
