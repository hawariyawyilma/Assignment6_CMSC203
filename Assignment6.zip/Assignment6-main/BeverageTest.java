import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BeverageTest {

	Beverage a;
	
	@BeforeEach
	void setUp() throws Exception {
	a = new Alcohol("Mohito",Size.MEDIUM,true);
	}

	@AfterEach
	void tearDown() throws Exception {
	a = null;
	}

	@Test
	void testBeverage() {
		assertTrue(a.getBevName().equals("Mohito") && a.getSize() == Size.MEDIUM && a.getType() == Type.ALCOHOL);
	}

	@Test
	void testGetBasePrice() {
		assertTrue(a.getBasePrice()==2.0);
	}

	@Test
	void testGetType() {
		assertTrue(a.getType() == Type.ALCOHOL);
	}

	@Test
	void testGetBevName() {
		assertTrue(a.getBevName().equals("Mohito"));
	}

	@Test
	void testGetSize() {
		assertTrue(a.getSize() == Size.MEDIUM);
	}

	@Test
	void testAddSizePrice() {
		assertTrue(a.addSizePrice()==3.00);
	}

	@Test
	void testToString() {
		System.out.println(a.toString());
		assertTrue(a.toString().equals("Mohito,MEDIUM,true"));
	}

	@Test
	void testCalcPrice() {
		// This is an abstract method which is tested in subclasses
		
	}

	@Test
	void testEqualsBeverage() {
		Beverage b = new Alcohol("Mohito",Size.MEDIUM,false);
		assertTrue(a.equals(b));
	}

}
