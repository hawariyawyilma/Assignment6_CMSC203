import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BevShopTest {
	
	BevShop a;

	@BeforeEach
	void setUp() throws Exception {
	a = new BevShop();
	}

	@AfterEach
	void tearDown() throws Exception {
	a = null;
	}

	@Test
	void testBevShop() {
		BevShop b = new BevShop();
		assertNotNull(b);
	}

	@Test
	void testIsValidTime() {
		assertFalse(a.isValidTime(3));
	}

	@Test
	void testGetMaxNumOfFruits() {
		assertTrue(a.getMaxNumOfFruits()==5);
	}

	@Test
	void testGetMinAgeForAlcohol() {
		assertTrue(a.getMinAgeForAlcohol()==21);
	}

	@Test
	void testIsMaxFruit() {
		assertTrue(a.isMaxFruit(5));
	}

	@Test
	void testGetMaxOrderForAlcohol() {
		assertTrue(a.getMaxOrderForAlcohol()==3);
	}

	@Test
	void testIsEligibleForMore() {
		assertFalse(a.isEligibleForMore());
	}

	@Test
	void testGetNumOfAlcoholDrink() {
		assertTrue(a.getNumOfAlcoholDrink()==0);
	}

	@Test
	void testIsValidAge() {
		assertTrue(a.isValidAge(22));
	}

	@Test
	void testStartNewOrder() {
		a.startNewOrder(0, Day.MONDAY, "", 0);
		assertNotNull(a.getCurrentOrder());
	}

	@Test
	void testProcessCoffeeOrder() {
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processCoffeeOrder("", Size.MEDIUM, false, false);
		assertTrue(a.getCurrentOrder().findNumOfBeveType(Type.COFFEE)==1);
	}

	@Test
	void testProcessAlcoholOrder() {
		a.startNewOrder(9, Day.MONDAY, "", 25);
		a.processAlcoholOrder("", Size.MEDIUM);
		assertTrue(a.getCurrentOrder().findNumOfBeveType(Type.ALCOHOL)==1);
	}

	@Test
	void testProcessSmoothieOrder() {
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processSmoothieOrder("", Size.MEDIUM, 0, false);
		assertTrue(a.getCurrentOrder().findNumOfBeveType(Type.SMOOTHIE)==1);
	}

	@Test
	void testFindOrder() {
		a.startNewOrder(9, Day.MONDAY, "", 0);
		assertTrue(a.findOrder(a.getCurrentOrder().getOrderNo())==0);
	}

	@Test
	void testTotalOrderPrice() {
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processCoffeeOrder("", Size.MEDIUM, false, false);
		assertEquals(a.totalOrderPrice(a.getCurrentOrder().getOrderNo()),3.00);
	}

	@Test
	void testTotalMonthlySale() {
		a.startNewOrder(9, Day.MONDAY, "", 25);
		a.processAlcoholOrder("", Size.MEDIUM);
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processSmoothieOrder("", Size.MEDIUM, 0, false);
		assertEquals(a.totalMonthlySale(),6.00);
	}

	@Test
	void testTotalNumOfMonthlyOrders() {
		a.startNewOrder(9, Day.MONDAY, "", 25);
		a.processAlcoholOrder("", Size.MEDIUM);
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processSmoothieOrder("", Size.MEDIUM, 0, false);
		assertTrue(a.totalNumOfMonthlyOrders()==2);
	}

	@Test
	void testGetCurrentOrder() {
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processAlcoholOrder("", Size.MEDIUM);
		a.startNewOrder(9, Day.MONDAY, "", 0);
		assertTrue(a.getCurrentOrder().findNumOfBeveType(Type.ALCOHOL)==0);
	}

	@Test
	void testGetOrderAtIndex() {
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processSmoothieOrder("", Size.MEDIUM, 0, false);
		assertTrue(a.getOrderAtIndex(0).findNumOfBeveType(Type.SMOOTHIE)==0);
	}

	@Test
	void testSortOrders() {
		a.startNewOrder(9, Day.MONDAY, "", 25);
		a.processAlcoholOrder("", Size.LARGE);
		a.startNewOrder(9, Day.MONDAY, "", 0);
		a.processSmoothieOrder("", Size.MEDIUM, 0, false);
		a.sortOrders();
		System.out.println(a.getOrderAtIndex(0).toString());
		System.out.println(a.toString()+"\n\n\n\n\n\n");
		System.out.println(a.getOrderAtIndex(0).findNumOfBeveType(Type.SMOOTHIE));
		System.out.println(a.getOrderAtIndex(0).findNumOfBeveType(Type.ALCOHOL));
		assertEquals(a.getOrderAtIndex(0).findNumOfBeveType(Type.SMOOTHIE),1);
		
	}

	@Test
	void testToString() {
		a.startNewOrder(9, Day.MONDAY, "", 25);
		a.processAlcoholOrder("", Size.MEDIUM);
		a.startNewOrder(9, Day.MONDAY, "", 25);
		a.processSmoothieOrder("", Size.MEDIUM, 0, false);
		System.out.println(a.toString());
	}

}
