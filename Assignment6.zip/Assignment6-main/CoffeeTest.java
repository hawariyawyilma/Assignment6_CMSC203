import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CoffeeTest {

	Coffee a;
	@BeforeEach
	void setUp() throws Exception {
	a = new Coffee("cappucino",Size.MEDIUM,false,false);
	}

	@AfterEach
	void tearDown() throws Exception {
	a = null;
	}

	@Test
	void testToString() {
		assertTrue(a.toString().equals("cappucino,MEDIUM,false,false,3.0"));
	}

	@Test
	void testCalcPrice() {
		assertTrue(a.calcPrice()==3.00);
	}

	@Test
	void testCoffee() {
		assertNotNull(a);
	}

	@Test
	void testGetExtraShot() {
		assertFalse(a.getExtraShot());
	}

	@Test
	void testGetExtraSyrup() {
		assertFalse(a.getExtraSyrup());
	}

	@Test
	void testEqualsCoffee() {
		Coffee b = new Coffee("cappucino",Size.MEDIUM,false,false);
		assertTrue(a.equals(b));
	}

}
