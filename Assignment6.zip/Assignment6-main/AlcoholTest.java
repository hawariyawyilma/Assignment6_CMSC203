import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AlcoholTest {

	Alcohol drink1;
	
	@BeforeEach
	void setUp() throws Exception {
		 drink1 = new Alcohol("Mohito",Size.SMALL,false);
	}

	@AfterEach
	void tearDown() throws Exception {
		drink1 = null;
	}

	@Test
	void testToString() {
		assertTrue(drink1.toString().equals("Mohito,SMALL,false"));
	}

	@Test
	void testCalcPrice() {
		assertEquals(drink1.calcPrice(),2.0);
	}

	@Test
	void testAlcohol() {
		assertTrue(drink1.getBevName().equals("Mohito") && drink1.getSize() == Size.SMALL && drink1.getType() == Type.ALCOHOL);
	}

	@Test
	void testEqualsAlcohol() {
		Alcohol drink2 = new Alcohol("Mohito",Size.SMALL,false);
		assertTrue(drink1.equals(drink2));
	}

	@Test
	void testIsWeekend() {
		assertTrue(!drink1.isWeekend());
	}

}
