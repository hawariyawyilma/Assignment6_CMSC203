/*
 * Class: CMSC203 
 * Instructor: Professor Kuijt
 * Description:
 * 		Utilize a BevShop class containing a list of Order objects with order details to process drinks.
 *		Each order has a list of beverages with subclasses Coffee, Alcohol, and Smoothie to store drink details.
 *		Additionally, each order contains a Customer object to store customer information.
 * Due: 12/4/2022
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Archer Romelli
*/


public class BevShopDriverApp {

	public static void main(String[] args) {
		final Day today = Day.SUNDAY;
		final int time = 20;
		
		BevShop Bradleys = new BevShop();
		
		System.out.println("Starting a new order");
		Bradleys.startNewOrder(time, today, "John Doe", 25);
		System.out.println(Bradleys.getCurrentOrder().toString());
		
		System.out.println("Adding three alcohol drinks...");
		Bradleys.processAlcoholOrder("Martini", Size.SMALL);	// Price should be $2.60
		Bradleys.processAlcoholOrder("Champagne", Size.MEDIUM);	// Price should be $3.60
		Bradleys.processAlcoholOrder("Beer", Size.LARGE);		// Price should be $4.60
		System.out.printf("New order total: $%.2f" + "\n",Bradleys.getCurrentOrder().calcOrderTotal());
		System.out.println("Adding a fourth alcoholic drink (should not be allowed)");
		Bradleys.processAlcoholOrder("Wine", Size.SMALL);
		System.out.printf("New order total: $%.2f" + "\n\n",Bradleys.getCurrentOrder().calcOrderTotal());
		
		System.out.println("Adding valid smoothie...");
		Bradleys.processSmoothieOrder("Tropical mix", Size.MEDIUM, 3, true);	// Price should be $6.00
		System.out.printf("New order total: $%.2f" + "\n",Bradleys.getCurrentOrder().calcOrderTotal());
		System.out.println("Adding smoothie with 10 fruits (should not be allowed)");
		Bradleys.processSmoothieOrder("Tropical mix", Size.MEDIUM, 12, true);
		System.out.printf("New order total: $%.2f" + "\n\n",Bradleys.getCurrentOrder().calcOrderTotal());
		
		System.out.println("Adding new coffee...");
		Bradleys.processCoffeeOrder("Tropical mix", Size.MEDIUM, true, true);	// Price should be $4.00
		System.out.printf("New order total: $%.2f" + "\n\n",Bradleys.getCurrentOrder().calcOrderTotal());
		System.out.printf("Final order total: $%.2f" + "\n",Bradleys.getCurrentOrder().calcOrderTotal());
	}
}