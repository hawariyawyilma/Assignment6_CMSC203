
public class BevShop implements BevShopInterface {

	private int numOfAlcoholDrink;				// Stores the number of alcoholic drinks in the current order
	private java.util.ArrayList<Order> orders;	// Stores all beverage shop orders in the current month

	public BevShop() {
		numOfAlcoholDrink = 0;
		this.orders = new java.util.ArrayList<Order>();
	}

	public boolean isValidTime(int time) {	// Checks if a given time is valid to serve a drink
		return (time >= 8 && time <= 23);
	}

	public int getMaxNumOfFruits() {
		return MAX_FRUIT;
	}

	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}

	public boolean isMaxFruit(int numOfFruits) {	// Checks if a given number of fruits is equal to the maximum fruit count
		return (numOfFruits == MAX_FRUIT);
	}

	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}

	public boolean isEligibleForMore() {	// Checks if an order is eligible for another alcoholic drink based on the current alcoholic drink count in the order
		return (numOfAlcoholDrink >= MAX_ORDER_FOR_ALCOHOL);
	}

	public int getNumOfAlcoholDrink() {
		return numOfAlcoholDrink;
	}

	public boolean isValidAge(int age) {	// Checks if a given age is legally able to purchase alcohol (using U.S. age requirement 21)
		return (age >= 21);
	}

	public void startNewOrder(int time, Day day, String customerName, int customerAge) {	// Starts a new order for the beverage shop
		orders.add(new Order(time, day, new Customer(customerName, customerAge)));
	}

	public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {	// Adds a new coffee beverage to the current order, if valid
		if (isValidTime(this.getCurrentOrder().getOrderTime()))
				this.getCurrentOrder().addNewBeverage(bevName, size, extraShot, extraSyrup);
		else System.out.println("Error: invalid time.");
	}

	public void processAlcoholOrder(String bevName, Size size) {	// Adds a new alcoholic beverage to the current order, if valid
		if (isValidTime(this.getCurrentOrder().getOrderTime()) && isValidAge(this.getCurrentOrder().getCustomer().getAge()) && numOfAlcoholDrink < MAX_ORDER_FOR_ALCOHOL) {
			this.getCurrentOrder().addNewBeverage(bevName, size);
			numOfAlcoholDrink++;
		} else System.out.println("Error: invalid time, age, or alcohol drink count.");
	}

	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) { // Adds a new smoothie beverage to the current order, if valid
		if (isValidTime(this.getCurrentOrder().getOrderTime()) && numOfFruits <= MAX_FRUIT && numOfFruits >= 0)
			this.getCurrentOrder().addNewBeverage(bevName, size, numOfFruits, addProtein);
		else System.out.println("Error: invalid time or fruit count.");
	}

	public int findOrder(int orderNo) {	// Locates and returns the index of an order by its order number, if it exists
		for (int i = 0; i < orders.size(); i++) {
			if (orders.get(i).getOrderNo() == orderNo)
				return i;
		}
		return -1;
	}

	public double totalOrderPrice(int orderNo) {	// Calculate the total price of an order given its order number
		return orders.get(findOrder(orderNo)).calcOrderTotal();
	}

	public double totalMonthlySale() {	//	Calculate the total sales of all orders in the month
		double total = 0;
		for (int i = 0; i < orders.size(); i++) {
			total += orders.get(i).calcOrderTotal();
		}
		return total;
	}

	public int totalNumOfMonthlyOrders() {
		return orders.size();
	}

	public Order getCurrentOrder() { // Returns the most recently created order
		java.util.ArrayList<Order> ordersCopy = new java.util.ArrayList<Order>(orders);
        return ordersCopy.get(ordersCopy.size() - 1);
	}

	public Order getOrderAtIndex(int index) { // Returns an order given its index in the order array
		Order value = orders.get(index);
		return value;
	}

	public void sortOrders() {	// Sorts the orders by price
		for (int i = 0;i<orders.size()-1;i++) {
			int index = i;
			for (int j=i+1;j<orders.size(); j++) {
				if (totalOrderPrice(orders.get(j).getOrderNo()) < totalOrderPrice(orders.get(index).getOrderNo())) {
					index = j;
				}
			}
			Order smaller = orders.get(index);
			orders.set(index,orders.get(i));
			orders.set(i,smaller);
		}

	}

	public String toString() {	// Represents all of the orders' data in String format
		String toString = "";
		for(int i=0;i<orders.size();i++) {
			toString += "Order #" + (i+1) + ": ";
			toString += orders.get(i).toString();
		}
		return toString;
	}
}
