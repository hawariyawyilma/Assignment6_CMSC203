
public class Coffee extends Beverage{

	private boolean extraShot, extraSyrup;	// Stores whether or not a drink includes an extra shot of coffee/syrup
	private final double EXTRA_SHOT_PRICE = 0.50, EXTRA_SYRUP_PRICE = 0.50;	// Stores the price of an extra shot of coffee/syrup
	
	public Coffee(String name, Size size, boolean extraShot, boolean extraSyrup) {
		super(name, Type.COFFEE, size);
		this.extraShot = extraShot;
		this.extraSyrup = extraSyrup;
	}
	
	public boolean getExtraShot() {
		return extraShot;
	}

	public boolean getExtraSyrup() {
		return extraSyrup;
	}
	
	public double calcPrice() {	// Calculates the total cost of the drink
		double total = super.addSizePrice();
		if(extraShot)
			total += EXTRA_SHOT_PRICE;
		if(extraSyrup)
			total += EXTRA_SYRUP_PRICE;
		return total;
	}
	
	public String toString() {	// Represents the drink data in String format
		return super.toString() + "," +
			extraShot + "," + extraSyrup + "," + this.calcPrice();
	}

	public boolean equals(Coffee anotherBev) {	// Checks if two drinks are the same
		return (super.equals(anotherBev) && anotherBev.getExtraShot() == this.extraShot && anotherBev.getExtraSyrup() == this.extraShot);
	}
}
