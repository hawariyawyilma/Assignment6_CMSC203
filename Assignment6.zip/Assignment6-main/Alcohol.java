
public class Alcohol extends Beverage{
	
	private boolean isWeekend;			// Stores whether or not this drink was ordered on a weekend
	final double WEEKEND_PRICE = 0.60;	// Stores the additional price if a drink is ordered on a weekend
	
	Alcohol(String bevName, Size size, boolean isWeekend){
		super(bevName,Type.ALCOHOL,size);
		this.isWeekend = isWeekend;
	}

	public double calcPrice() {					// Calculates the total cost of the drink
		double total = super.addSizePrice();
		if(isWeekend)
			total += WEEKEND_PRICE;
		return total;
	}

	public String toString() {					// Represents the drink data in String format
		return (super.toString() + "," + isWeekend);
	}
	
	public boolean equals(Alcohol anotherBev) {	// Checks if two drinks are the same
		return (super.equals(anotherBev) && anotherBev.isWeekend() == this.isWeekend());
	}
	
	public boolean isWeekend() {
		return this.isWeekend;
	}
}
