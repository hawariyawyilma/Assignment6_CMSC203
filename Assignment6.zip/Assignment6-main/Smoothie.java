
public class Smoothie extends Beverage{
	
	private int numOfFruits;	// Stores the number of fruits in a smoothie drink
	private boolean addProtein;	// Stores whether or not the drink contains protein powder
	private double FRUIT_PRICE = 0.50, PROTEIN_PRICE = 1.50;	// Stores the cost per fruit and for protein powder

	public Smoothie(String bevName, Size size, int numOfFruits, boolean addProtein) {
		super(bevName, Type.SMOOTHIE, size);
		this.numOfFruits = numOfFruits;
		this.addProtein = addProtein;
	}

	public int getNumOfFruits() {
		return numOfFruits;
	}

	public boolean getAddProtein() {
		return addProtein;
	}
	
	public String toString() { // Represents the drink data in String format
		return super.toString() + "," + addProtein
			+ "," + numOfFruits + "," + calcPrice();
	}

	public boolean equals(Smoothie anotherBev) { // Checks if two drinks are the same
		return (super.equals(anotherBev) && anotherBev.getNumOfFruits() == this.numOfFruits && anotherBev.getAddProtein() == this.addProtein);
	}

	public double calcPrice() { // Calculates the total cost of the drink
		double total = super.addSizePrice();
		total += FRUIT_PRICE * numOfFruits;
		if(addProtein)
			total += PROTEIN_PRICE;
		return total;
	}
}
