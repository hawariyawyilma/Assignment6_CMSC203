import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerTest {

	Customer a;
	
	@BeforeEach
	void setUp() throws Exception {
	a = new Customer("Bob",25);
	}

	@AfterEach
	void tearDown() throws Exception {
	a = null;
	}

	@Test
	void testCustomerStringInt() {
		assertNotNull(a);
	}

	@Test
	void testCustomerCustomer() {
		assertNotNull(new Customer(a));
	}

	@Test
	void testGetAge() {
		assertTrue(a.getAge()==25);
	}

	@Test
	void testSetAge() {
		a.setAge(10);
		assertTrue(a.getAge()==10);
	}

	@Test
	void testGetName() {
		assertTrue(a.getName()=="Bob");
	}

	@Test
	void testSetName() {
		a.setName("john");
		assertTrue(a.getName()=="john");
	}

	@Test
	void testToString() {
		assertTrue(a.toString().equals("Bob,25"));
	}

}
