
public class Order implements OrderInterface, Comparable<Order> {

	private int orderTime;
	private Day orderDay;
	private Customer cust;
	private int orderNumber;
	private java.util.ArrayList<Beverage> beverages = new java.util.ArrayList<Beverage>();
	
	public Order(int orderTime, Day orderDay, Customer cust) {
		this.orderTime = orderTime;
		this.orderDay = orderDay;
		this.cust = cust;
		this.orderNumber = generateOrder();
	}
	
	public int generateOrder() {	// Generates an order number at random
		java.util.Random rand = new java.util.Random();
		return rand.nextInt(10001, 90000);
	}
	
	public int getOrderNo(){
		return orderNumber;
	}
	
	public int getOrderTime() {
		return orderTime;
	}

	public Day getOrderDay() {
		return orderDay;
	}

	public Customer getCustomer() {
		return new Customer(cust);
	}
	
	public Day getDay() {
		return orderDay;
	}

	public boolean isWeekend() {	// Checks if the order day is a weekend day
		return (orderDay == Day.SATURDAY || orderDay == Day.SUNDAY);
	}
	
	public Beverage getBeverage(int itemNo) {	// returns the beverage at a given index in the list
		java.util.ArrayList<Beverage> beveragesCopy = new java.util.ArrayList<Beverage>(beverages);
		return beveragesCopy.get(itemNo);
	}
	
	public int getTotalItems() {
		return beverages.size();
	}

	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup) {	// Adds a new coffee to the beverage list
		beverages.add(new Coffee(bevName,size,extraShot,extraSyrup));
	}
	
	public void addNewBeverage(String bevName, Size size) { // Adds a new alcoholic drink to the beverage list
		beverages.add(new Alcohol(bevName,size,this.isWeekend()));
	}
	
	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein) {	// Adds a new smoothie to the beverage list
		beverages.add(new Smoothie(bevName,size,numOfFruits,addProtein));
	}

	public double calcOrderTotal() {	// Calculates the total price of the order
		double total = 0;
		for(int i=0;i<beverages.size();i++) {
			total += beverages.get(i).calcPrice();
		}
		return total;
	}

	public int findNumOfBeveType(Type type) {	// Finds the number of beverages of a given type
		int total = 0;
		for(int i=0;i<beverages.size();i++) {
			if(beverages.get(i).getType() == type)
				total++;
		}
		return total;
	}
	
	public String toString() {	// Represents the order information in String format
		String toString = orderNumber + "," + orderTime + "," + orderDay + "," + cust.getName() + "," + cust.getAge();
		for(int i=0;i<beverages.size();i++) {
			if (i == 0)
				toString += "\nDrinks: ";
			else toString += "\n";
			toString += beverages.get(i).getBevName() + "," + beverages.get(i).getType() + ",$" + beverages.get(i).calcPrice();
		}
		toString += "\n";
		return toString;
	}
	
	public int compareTo(Order anotherOrder) {
		if(this.orderNumber > anotherOrder.getOrderNo()) {
			return 1;
		} else if(this.orderNumber < anotherOrder.getOrderNo()) {
			return -1;
		} else return 0;
	}
}
