import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SmoothieTest {

	Smoothie a;
	
	@BeforeEach
	void setUp() throws Exception {
	a = new Smoothie("Drink",Size.MEDIUM,3,false);
	}

	@AfterEach
	void tearDown() throws Exception {
	a = null;
	}

	@Test
	void testToString() {
		assertTrue(a.toString().equals("Drink,MEDIUM,false,3,4.5"));
	}

	@Test
	void testCalcPrice() {
		assertTrue(a.calcPrice()==4.50);
	}

	@Test
	void testSmoothie() {
		assertNotNull(a);
	}

	@Test
	void testGetNumOfFruits() {
		assertEquals(a.getNumOfFruits(),3);
	}

	@Test
	void testGetAddProtein() {
		assertFalse(a.getAddProtein());
	}

	@Test
	void testEqualsSmoothie() {
		Smoothie b = new Smoothie("Drink",Size.MEDIUM,3,false);
		assertTrue(a.equals(b));
	}

}
